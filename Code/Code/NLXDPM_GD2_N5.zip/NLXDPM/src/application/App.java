
package application;
import UI.DashboardFrame;
import plugins.notification.NotificationPlugin;
import core.plugin.PluginManager;
import core.service.taskService;
public class App {
    public static void main(String[] args){
              
     
       
        PluginManager pluginManager = new PluginManager();
            
        javax.swing.SwingUtilities.invokeLater(() -> {
            new DashboardFrame(pluginManager).setVisible(true);
        });
    
        
        pluginManager.registerPlugin(new NotificationPlugin());

        taskService taskservice = new taskService(pluginManager);
        
        taskservice.createTask("Text");
    }
}
