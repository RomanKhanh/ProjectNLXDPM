
package core.error;
import javax.swing.JOptionPane;

public class ErrorHandle {
     public static void handle(Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(
            null,
            e.getMessage(),
            "Application Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}