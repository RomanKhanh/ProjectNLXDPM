package core.plugin;

import java.util.ArrayList;
import java.util.List;


public class PluginManager {
    private List<Plugin> plugins;
        
    public PluginManager() {
        PluginLoader loader = new PluginLoader();
        this.plugins = loader.loadPlugins(); 
    }

    public List<Plugin> getPlugins() {
        return plugins;
    }
       public void registerPlugin(Plugin plugin) {
        plugins.add(plugin);
    }
         public void loadPlugins() throws Exception {
        PluginLoader loader = new PluginLoader();
        plugins.addAll(loader.loadPlugins());
    }
      public void notifyAllPlugins(EventContext ctx) {
        for (Plugin p : plugins) {
            p.execute(ctx);
        }
    }
}