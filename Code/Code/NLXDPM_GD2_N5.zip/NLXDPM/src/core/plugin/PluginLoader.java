package core.plugin;

import java.util.ArrayList;
import java.util.List;
import core.error.PluginException;

public class PluginLoader {

    public List<Plugin> loadPlugins() {
        List<Plugin> plugins = new ArrayList<>();

        try {
            Class<?> clazz = Class.forName("plugins.notification.HelloWorld");

            if (Plugin.class.isAssignableFrom(clazz)) {
                Plugin plugin = (Plugin)
                        clazz.getDeclaredConstructor().newInstance();
                plugins.add(plugin);
            } else {
                throw new PluginException(
                    "Class không implement Plugin: " + clazz.getName()
                );
            }

        } catch (Exception e) {
            throw new PluginException("Lỗi khi load plugin", e);
        }

        return plugins;
    }
}
