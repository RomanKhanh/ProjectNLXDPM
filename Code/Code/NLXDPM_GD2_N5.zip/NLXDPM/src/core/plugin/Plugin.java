package core.plugin;


public interface Plugin {
    String getName();
    public void execute(EventContext ctx);
}
