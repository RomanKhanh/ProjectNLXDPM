package UI;

import javax.swing.*;
import java.awt.*;
import core.plugin.EventContext;
import core.plugin.PluginManager;

public class DashboardFrame extends JFrame {
    private PluginManager pluginManager;

    public DashboardFrame(PluginManager pluginManager) {
        this.pluginManager = pluginManager;

        setTitle("NLXDPM Dashboard");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initMenu();
    }


    private void initMenu() {
        JMenuBar menuBar = new JMenuBar();

        JMenu pluginMenu = new JMenu("Plugin");
        JMenuItem loadItem = new JMenuItem("Load & Run");

        loadItem.addActionListener(e -> {
            try {
                pluginManager.loadPlugins();
                pluginManager.notifyAllPlugins(
                    new EventContext("UI_LOAD")
                );
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
                );
            }
        });

        pluginMenu.add(loadItem);
        menuBar.add(pluginMenu);
        setJMenuBar(menuBar);
    }
}
