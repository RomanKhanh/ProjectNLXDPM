
package plugins.notification;
import javax.swing.JOptionPane;


import core.plugin.Plugin;
import core.plugin.EventContext;

public class HelloWorld implements Plugin {

    @Override
    public void execute(EventContext context) {
        JOptionPane.showMessageDialog(
        null,
        "Hello World Plugin running trung dz no 1st"
    );
}
    @Override
    public String getName() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
