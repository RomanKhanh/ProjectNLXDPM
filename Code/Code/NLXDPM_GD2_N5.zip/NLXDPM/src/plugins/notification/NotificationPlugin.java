
package plugins.notification;

import core.plugin.EventContext;
import core.plugin.Plugin;

public class NotificationPlugin implements Plugin {

    @Override
    public void execute(EventContext ctx) {
             System.out.println("Notification plugin running");
       }
       

    @Override
    public String getName() {
         return "Notification Plugin";
    }
}
