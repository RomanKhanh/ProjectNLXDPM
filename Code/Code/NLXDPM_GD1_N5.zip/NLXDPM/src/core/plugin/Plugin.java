package core.plugin;


public interface Plugin {
    public void execute(EventContext ctx);
}
